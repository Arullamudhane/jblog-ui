import "../styles/Footer.css";
function Footer() {
  return (
    <>
      <div className='foot'></div>
    </>
  );
}

export default Footer;
