import * as React from 'react';
import CommentBox from '../components/CommentBox';


export default function SideBar() {
    const products = ['orange', 'apple', 'watermelon'];
    const list = []

    for (let i = 0; i < 10; i++) {
        list.push(<CommentBox />);

    }
    return (<>
        <div className="sidebar">

            {list}
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            v
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />
            Scrollbar Test!<br />


        </div>
    </>);
}