import '../styles/CommentBox.css';
import profilePic from '../assets/pics.png';
function CommentBox({ content, author }) {

    return (
        <div className='comment-box'>
            <div className='cb__header'>
                <div className='cb__header__pp'>
                    <img src={profilePic} alt="fireSpot" className='profilePic' />

                </div>
                <div className='cb__header_auth'>
                    <p>loraaaaa</p>
                    <p>11/23/4343</p>

                </div>
            </div>
            {/*  */}
            <div className='cb__body'>
                Adbuqebd OUWHD euihdiuwe weiuhdipwuehdewd ewudhweuihewf weuifhuwehf wefu9hwe[fef wuehfu9[w]] wfeh iuwehfpiu  wiuehfiupwef uiefwhuih
                Adbuqebd OUWHD euihdiuwe weiuhdipwuehdewd ewudhweuihewf weuifhuwehf wefu9hwe[fef wuehfu9[w]] wfeh iuwehfpiu  wiuehfiupwef uiefwhuih
                Adbuqebd OUWHD euihdiuwe weiuhdipwuehdewd ewudhweuihewf weuifhuwehf wefu9hwe[fef wuehfu9[w]] wfeh iuwehfpiu  wiuehfiupwef uiefwhuih
                Adbuqebd OUWHD euihdiuwe weiuhdipwuehdewd ewudhweuihewf weuifhuwehf wefu9hwe[fef wuehfu9[w]] wfeh iuwehfpiu  wiuehfiupwef uiefwhuih
                Adbuqebd OUWHD euihdiuwe weiuhdipwuehdewd ewudhweuihewf weuifhuwehf wefu9hwe[fef wuehfu9[w]] wfeh iuwehfpiu  wiuehfiupwef uiefwhuih
                Adbuqebd OUWHD euihdiuwe weiuhdipwuehdewd ewudhweuihewf weuifhuwehf wefu9hwe[fef wuehfu9[w]] wfeh iuwehfpiu  wiuehfiupwef uiefwhuih
                Adbuqebd OUWHD euihdiuwe weiuhdipwuehdewd ewudhweuihewf weuifhuwehf wefu9hwe[fef wuehfu9[w]] wfeh iuwehfpiu  wiuehfiupwef uiefwhuih
                Adbuqebd OUWHD euihdiuwe weiuhdipwuehdewd ewudhweuihewf weuifhuwehf wefu9hwe[fef wuehfu9[w]] wfeh iuwehfpiu  wiuehfiupwef uiefwhuih
                Adbuqebd OUWHD euihdiuwe weiuhdipwuehdewd ewudhweuihewf weuifhuwehf wefu9hwe[fef wuehfu9[w]] wfeh iuwehfpiu  wiuehfiupwef uiefwhuih
                Adbuqebd OUWHD euihdiuwe weiuhdipwuehdewd ewudhweuihewf weuifhuwehf wefu9hwe[fef wuehfu9[w]] wfeh iuwehfpiu  wiuehfiupwef uiefwhuih
                Adbuqebd OUWHD euihdiuwe weiuhdipwuehdewd ewudhweuihewf weuifhuwehf wefu9hwe[fef wuehfu9[w]] wfeh iuwehfpiu  wiuehfiupwef uiefwhuih
                Adbuqebd OUWHD euihdiuwe weiuhdipwuehdewd ewudhweuihewf weuifhuwehf wefu9hwe[fef wuehfu9[w]] wfeh iuwehfpiu  wiuehfiupwef uiefwhuih
                Adbuqebd OUWHD euihdiuwe weiuhdipwuehdewd ewudhweuihewf weuifhuwehf wefu9hwe[fef wuehfu9[w]] wfeh iuwehfpiu  wiuehfiupwef uiefwhuih
                Adbuqebd OUWHD euihdiuwe weiuhdipwuehdewd ewudhweuihewf weuifhuwehf wefu9hwe[fef wuehfu9[w]] wfeh iuwehfpiu  wiuehfiupwef uiefwhuih
                Adbuqebd OUWHD euihdiuwe weiuhdipwuehdewd ewudhweuihewf weuifhuwehf wefu9hwe[fef wuehfu9[w]] wfeh iuwehfpiu  wiuehfiupwef uiefwhuih
                Adbuqebd OUWHD euihdiuwe weiuhdipwuehdewd ewudhweuihewf weuifhuwehf wefu9hwe[fef wuehfu9[w]] wfeh iuwehfpiu  wiuehfiupwef uiefwhuih
                Adbuqebd OUWHD euihdiuwe weiuhdipwuehdewd ewudhweuihewf weuifhuwehf wefu9hwe[fef wuehfu9[w]] wfeh iuwehfpiu  wiuehfiupwef uiefwhuih
                Adbuqebd OUWHD euihdiuwe weiuhdipwuehdewd ewudhweuihewf weuifhuwehf wefu9hwe[fef wuehfu9[w]] wfeh iuwehfpiu  wiuehfiupwef uiefwhuih
                Adbuqebd OUWHD euihdiuwe weiuhdipwuehdewd ewudhweuihewf weuifhuwehf wefu9hwe[fef wuehfu9[w]] wfeh iuwehfpiu  wiuehfiupwef uiefwhuih
                Adbuqebd OUWHD euihdiuwe weiuhdipwuehdewd ewudhweuihewf weuifhuwehf wefu9hwe[fef wuehfu9[w]] wfeh iuwehfpiu  wiuehfiupwef uiefwhuih
                Adbuqebd OUWHD euihdiuwe weiuhdipwuehdewd ewudhweuihewf weuifhuwehf wefu9hwe[fef wuehfu9[w]] wfeh iuwehfpiu  wiuehfiupwef uiefwhuih
                Adbuqebd OUWHD euihdiuwe weiuhdipwuehdewd ewudhweuihewf weuifhuwehf wefu9hwe[fef wuehfu9[w]] wfeh iuwehfpiu  wiuehfiupwef uiefwhuih
                Adbuqebd OUWHD euihdiuwe weiuhdipwuehdewd ewudhweuihewf weuifhuwehf wefu9hwe[fef wuehfu9[w]] wfeh iuwehfpiu  wiuehfiupwef uiefwhuih
                Adbuqebd OUWHD euihdiuwe weiuhdipwuehdewd ewudhweuihewf weuifhuwehf wefu9hwe[fef wuehfu9[w]] wfeh iuwehfpiu  wiuehfiupwef uiefwhuih

            </div>
        </div>
    );

}
export default CommentBox;